
USE UNIVERSITY;

DROP TABLE IF EXISTS `Booking`;

CREATE TABLE `Booking` (
  `bookingId` varchar(30) NOT NULL,
  `lecturerId` varchar(10) NOT NULL,
  `roomNumber` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `duration` int(11) NOT NULL,
  `reason` varchar(1000) NOT NULL,
  `noAttendees` int(4) NOT NULL,
  PRIMARY KEY (`bookingId`),
  KEY `lecturerId` (`lecturerId`),
  KEY `roomNumber` (`roomNumber`),
  CONSTRAINT `Booking_ibfk_1` FOREIGN KEY (`lecturerId`) REFERENCES `Lecturer` (`lecturerId`),
  CONSTRAINT `Booking_ibfk_2` FOREIGN KEY (`roomNumber`) REFERENCES `TeachingRooms` (`roomNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `Booking` WRITE;
/*!40000 ALTER TABLE `Booking` DISABLE KEYS */;
INSERT INTO `Booking` VALUES ('B1','l2','H01','2020-04-20','12:30:00',3,'Practical-Lab-Class',25),('B2','L2','C01','2020-04-25','12:30:00',4,'Covid-conference',38),('B3','L5','C02','2020-04-21','09:30:00',1,'Information-system-lab',15),('B4','L3','C02','2020-04-11','09:30:00',2,'Computer-architecture',27),('B5','L1','L01','2020-03-15','09:30:00',2,'Lecture-tort-law',55),('B7','l4','C02','2020-04-22','12:38:00',4,'conference',60);
/*!40000 ALTER TABLE `Booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lecturer`
--

DROP TABLE IF EXISTS `Lecturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `Lecturer` (
  `lecturerId` varchar(10) NOT NULL,
  `lecturerName` varchar(150) DEFAULT NULL,
  `lecturerEmail` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`lecturerId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `Lecturer` WRITE;
/*!40000 ALTER TABLE `Lecturer` DISABLE KEYS */;
INSERT INTO `Lecturer` VALUES ('L1','Hishaam','Hishaam@gmail.com'),('L2','Faiz','Faiz@gmail.com'),('L3','Summayyah','Summayyah@gmail.com'),('L4','Sooltana','Sooltana@gmail.com'),('L5','Imrane','Imrane@gmail.com');
/*!40000 ALTER TABLE `Lecturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TeachingRooms`
--

DROP TABLE IF EXISTS `TeachingRooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;

CREATE TABLE `TeachingRooms` (
  `maximumCapacity` int(11) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `roomNumber` varchar(10) NOT NULL,
  PRIMARY KEY (`roomNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `TeachingRooms` WRITE;
/*!40000 ALTER TABLE `TeachingRooms` DISABLE KEYS */;
INSERT INTO `TeachingRooms` VALUES (50,'conference','C01'),(65,'conference','C02'),(60,'hall','H01'),(40,'hall','H02'),(70,'lab','L01');
/*!40000 ALTER TABLE `TeachingRooms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

