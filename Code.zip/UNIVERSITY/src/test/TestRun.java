package test;

import common.Booking;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

import static org.junit.Assert.*;

public class TestRun {

    @Test
    public void ShouldReturnLISTALL() {

        TestMethod testmethod = new TestMethod();

        String okay = "LISTALL";
        InputStream in    = new ByteArrayInputStream(okay.getBytes());
        System.setIn(in);

        assertEquals("LISTALL", testmethod.userInputCheck());
    }

    @Test
    public void ShouldReturnLISTLECTURER() {

        TestMethod testmethod = new TestMethod();

        String okay = "LISTLECTURER";
        InputStream in    = new ByteArrayInputStream(okay.getBytes());
        System.setIn(in);

        assertEquals("LISTLECTURER", testmethod.userInputCheck());
    }


    @Test
    public void ShouldReturnLISTROOMNUMBER() {

        TestMethod testmethod = new TestMethod();

        String okay = "LISTROOMNUMBER";
        InputStream in    = new ByteArrayInputStream(okay.getBytes());
        System.setIn(in);

        assertEquals("LISTROOMNUMBER", testmethod.userInputCheck());
    }

    @Test
    public void ShouldReturnLISTDATE() {
        TestMethod testmethod = new TestMethod();

        String okay = "LISTDATE";
        InputStream in    = new ByteArrayInputStream(okay.getBytes());
        System.setIn(in);

        assertEquals("LISTDATE", testmethod.userInputCheck());
    }

    @Test
    public void ShouldReturnLISTAVAILABLE() {
        TestMethod testmethod = new TestMethod();

        String okay = "LISTAVAILABLE";
        InputStream in    = new ByteArrayInputStream(okay.getBytes());
        System.setIn(in);

        assertEquals("LISTAVAILABLE", testmethod.userInputCheck());
    }

    @Test
    public void ShouldReturnDELETE() {
        TestMethod testmethod = new TestMethod();

        String okay = "DELETE";
        InputStream in    = new ByteArrayInputStream(okay.getBytes());
        System.setIn(in);

        assertEquals("DELETE", testmethod.userInputCheck());
    }

    @Test
    public void testSetterBookingId() {
        Booking book =new Booking();
        book.setBookingId("test");
        assertEquals("bookingId", "test", book.getBookingId());
    }

    @Test
    public void testSetterLecturerId() {
        Booking book =new Booking();
        book.setLecturerId("test");
        assertEquals("lecturerId", "test", book.getLecturerId());
    }

    @Test
    public void testSetterRoomNumber() {
        Booking book =new Booking();
        book.setRoomNumber("test");
        assertEquals("roomNumber", "test", book.getRoomNumber());
    }

}


