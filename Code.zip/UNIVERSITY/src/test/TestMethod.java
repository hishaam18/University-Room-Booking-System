package test;

import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class TestMethod {

    public static String userInputCheck () {

Scanner sc = new Scanner(System.in);
return sc.nextLine();

}

}
