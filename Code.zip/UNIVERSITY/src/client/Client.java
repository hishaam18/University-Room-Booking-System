package client;

import common.Booking;
import common.Split;
import common.TeachingRooms;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Scanner;

public class Client {

    public static void main(String[] args)  {

        final int PORT =8000;
        final String HOSTNAME = "localhost";

            try     (Socket ClientSocket = new Socket(HOSTNAME, PORT);
                    OutputStream outClient = ClientSocket.getOutputStream();
                    ObjectOutputStream writeServer = new ObjectOutputStream(outClient);
                    ObjectInputStream inputobj = new ObjectInputStream(ClientSocket.getInputStream()))
            {
                    Scanner scanner = new Scanner(System.in);

                while(true) {

                    //Providing command List to user
                    System.out.println( "\n" + "Please Choose your command :" +
                            "\n" + " " +
                            "\n" + "1. ADD <bookingId> <lecturerId> <roomNumber> <date> <time> <duration> <reason> <noAttendees> --> To add a new Booking" +
                            "\n" + "2. UPDATE <bookingId> <lecturerId> <roomNumber> <date> <time> <duration> <reason> <noAttendees> --> To update a specific Booking" +
                            "\n" + "3. LISTALL --> To list all Bookings " +
                            "\n" + "4. LISTLECTURER <lecturerId> --> To list all bookings for a specific lecturer" +
                            "\n" + "5. LISTROOMNUMBER <roomNumber> --> To list all bookings for a specific room" +
                            "\n" + "6. LISTDATE <date> --> To list all bookings for a specific date" +
                            "\n" + "7. LISTAVAILABLE <date> <maximumCapacity <type>" +
                            "\n" + "8. DELETE <bookingId> --> To delete a specific booking" +
                            "\n" + "9. QUIT --> to Exit the Program ");

                    System.out.println("\n" + " "  +"Command:");

                    //allowing User input
                     String userInput = scanner.nextLine();


                    //sending userInput to server
                    writeServer.writeObject(userInput);

                    //---------------------------------------** AFTER PROCESSED DATA RETURNS FROM SERVER **--------------------------------------------------//

                    //split to read line by line
                    String[] splitLine = Split.splitLine(userInput);
//----

                        boolean testListAll;
                        if (!splitLine[0].equalsIgnoreCase("LISTALL")) {
                            testListAll = false;
                        }


                    //1.ADD
                     if (splitLine[0].contains("ADD") || splitLine[0].contains("add") ) {
                        if (splitLine.length < 9) {
                            System.out.println("Not enough arguments! Please check the format." + "\n" + " Note: Words in 'reason' column should be seperated using '-' ");
                        } else if (splitLine.length > 9) {
                            System.out.println("Too many arguments! Please check the format"+ "\n" + " Note: Words in 'reason' column should be seperated using '-' ");
                        }else if(!splitLine[1].startsWith("B")){
                            System.out.println("Error ! bookingId must start with 'B', format is : 'BX' (eg: B1) ");
                        }else if (splitLine[1].length() <2 ) {
                            System.out.println(" Error ! bookingId must contain at least 2 characters, format is : 'BX' (eg: B1) ");
                        }else if ( !splitLine[2].matches("L1|L2|L3|L4|L5") ) {
                            System.out.println("Error ! Lecturer does not exist, Please choose from the following: " + "\n" + "L1, L2, L3, L4, L5");
                        }else if ( !splitLine[3].matches("C01|C02|H01|H02|L01") ) {
                            System.out.println("Error ! Room does not exist, Please choose from the following: " + "\n" + "C01, C02, H01, H02, L01");
                        }else if (!splitLine[4].matches("^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])")){
                            System.out.println("Invalid date! format is: YYYY-MM-DD");
                        }else if(!splitLine[6].matches("[0-9]") ) {
                            System.out.println("Error ! duration can only be in Numbers eg: '1' ");
                        }else if(splitLine[7].trim() == " ") {
                            System.out.println("Error! reason cannot contain empty spaces. Format: XXXX-XX-XXXXX. eg: 'For-practical-lab-class-2' ");
                        }else if(splitLine[3].matches("C01") && !splitLine[8].matches("[0-4][0-9]")) {
                            System.out.println("Error ! C01 can only accomodate up to 49 people");
                        }else if( (splitLine[3].matches("C02")) && (!splitLine[8].matches("[0-4][0-9]"))) {
                            System.out.println("Error ! C02 can only accomodate up to 49 people");
                        }else if( (splitLine[3].matches("H01")) && (!splitLine[8].matches("[0-7][0-9]"))) {
                            System.out.println("Error ! H01 can only accomodate up to 79 people");
                        }else if( (splitLine[3].matches("H02")) && (!splitLine[8].matches("[0-7][0-9]"))) {
                            System.out.println("Error ! H02 can only accomodate up to 79 people");
                        }else if( (splitLine[3].matches("L01")) && (!splitLine[8].matches("[0-3][0-9]"))) {
                            System.out.println("Error ! H02 can only accomodate up to 39 people");
                        }

                        //add B24 L2 C01 2020-04-21 14:00 2 lab-class 40

                        else {
                            retrieveAddMethod(inputobj, userInput);
                        } }

                     //2.UPDATE Booking
                     else if (splitLine[0].equalsIgnoreCase("UPDATE") || splitLine[0].equalsIgnoreCase("update")) {

                         if (splitLine.length < 9) {
                             System.out.println("Not enough arguments! Please check the format" + "\n" + " Note: Words in 'reason' column should be seperated using '-' ");
                         } else if (splitLine.length > 9) {
                             System.out.println("Too many arguments! Please check the format" + "\n" + " Note: Words in 'reason' column should be seperated using '-' ");
                         }else if(!splitLine[1].startsWith("B")){
                             System.out.println("Error ! bookingId must start with 'B', format is : 'BX' (eg: B1) ");
                         }else if (splitLine[1].length() <2 ) {
                             System.out.println(" Error ! bookingId must contain at least 2 characters, format is : 'BX' (eg: B1) ");
                         }else if ( !splitLine[2].matches("L1|L2|L3|L4|L5") ) {
                             System.out.println("Error ! Lecturer does not exist, Please choose from the following: " + "\n" + "L1, L2, L3, L4, L5");
                         }else if ( !splitLine[3].matches("C01|C02|H01|H02|L01") ) {
                             System.out.println("Error ! Room does not exist, Please choose from the following: " + "\n" + "C01, C02, H01, H02, L01");
                         }else if (!splitLine[4].matches("^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])")){
                             System.out.println("Invalid date! format is: YYYY-MM-DD");
                         }else if(!splitLine[6].matches("[0-9]") ) {
                             System.out.println("Error ! duration can only be in Numbers eg: '1' ");
                         }else if(splitLine[7].trim() == " ") {
                             System.out.println("Error! reason cannot contain empty spaces. Format: XXXX-XX-XXXXX. eg: 'For-practical-lab-class-2' ");
                         }else if(splitLine[3].matches("C01") && !splitLine[8].matches("[0-4][0-9]")) {
                             System.out.println("Error ! C01 can only accomodate up to 49 people");
                         }else if( (splitLine[3].matches("C02")) && (!splitLine[8].matches("[0-4][0-9]"))) {
                             System.out.println("Error ! C02 can only accomodate up to 49 people");
                         }else if( (splitLine[3].matches("H01")) && (!splitLine[8].matches("[0-7][0-9]"))) {
                             System.out.println("Error ! H01 can only accomodate up to 79 people");
                         }else if( (splitLine[3].matches("H02")) && (!splitLine[8].matches("[0-7][0-9]"))) {
                             System.out.println("Error ! H02 can only accomodate up to 79 people");
                         }else if( (splitLine[3].matches("L01")) && (!splitLine[8].matches("[0-3][0-9]"))) {
                             System.out.println("Error ! H02 can only accomodate up to 39 people");
                         }

                         //update B2 L3 H02 2020-04-26 14:00 3 here-is-reason 40

                         else {
                             retrieveUpdateMethod(inputobj, userInput);
                         } }

                     //3.LISTALL
                     else if (splitLine[0].equalsIgnoreCase("LISTALL")) {
                         if (splitLine.length > 1) {
                             System.out.println("Too many arguments!");
                         }
                         else {
                             retrieveListAllMethod(inputobj, userInput); //call method retrieveListAllMethod
                         } }


                     //4.LIST LECTURER
                    else if (splitLine[0].equalsIgnoreCase("LISTLECTURER")){
                        if (splitLine.length > 2) {
                           System.out.println("Too many arguments");
                        }else if(splitLine.length < 2) {
                            System.out.println("Not Enough arguments");
                        } else if (!splitLine[1].startsWith("L") ) {
                            System.out.println("Error ! lecturerId must must start with 'L',format is : 'LX' (eg: L1) ");
                        }else if (splitLine[1].length() <2 ) {
                            System.out.println(" Error ! lecturerId must contain at least 2 characters, format is :'LX' (eg: L1) ");
                        }
                        else {
                            retrieveQueryList(inputobj, userInput);
                        } }


                    //5. LIST ROOMNUMBER
                    else if (splitLine[0].equalsIgnoreCase("LISTROOMNUMBER")) {
                        if (splitLine.length > 2) {
                            System.out.println("Too many arguments");
                        }else if(splitLine.length < 2) {
                            System.out.println("Not Enough arguments");
                        } else if ((!splitLine[1].contains("C01")) ||  (!splitLine[1].contains("C02")) ||   (!splitLine[1].contains("H01"))  ||  (!splitLine[1].contains("H02")) ||  (!splitLine[1].contains("L01")) ) {
                            System.out.println("Error ! Room does not exist, Please choose from the following: " + "\n" + "C01, C02, H01, H02, L01");
                        } else {
                            retrieveQueryList(inputobj, userInput);
                        } }


                    //6. LISTDATE
                    else if  (splitLine[0].equalsIgnoreCase("LISTDATE") || splitLine[0].equalsIgnoreCase("listdate")) {
                        if (splitLine.length > 2) {
                            System.out.println("Too many arguments");
                        }else if(splitLine.length < 2) {
                            System.out.println("Not Enough arguments");
                        }else if (!splitLine[1].matches("^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])")){
                            System.out.println("Invalid date! format is: YYYY-MM-DD");
                        }
                        else {
                            retrieveQueryList(inputobj, userInput);
                        } }


                    //7. LIST AVAILABLE ROOM
                    else if (splitLine[0].contains("LISTAVAILABLE") || splitLine[0].contains("listavailable")) {

                        if (splitLine.length > 4) {
                            System.out.println("Too many arguments");
                        }else if(splitLine.length < 4) {
                            System.out.println("Not Enough arguments");
                        } else {
                            retrieveAvailableMethod(inputobj, userInput);
                        } }


                    //8.DELETE BOOKING
                    else if (splitLine[0].equalsIgnoreCase("DELETE")) {
                        if (splitLine.length > 2) {
                            System.out.println("Too many arguments");
                        }else if(splitLine.length < 2) {
                            System.out.println("Not Enough arguments");
                        }else if(!splitLine[1].startsWith("B")){
                            System.out.println("Error ! bookingId must start with 'B', format is : 'BX' (eg: B1) ");
                        }else if (splitLine[1].length() <2 ) {
                            System.out.println(" Error ! bookingId must contain at least 2 characters, format is : 'BX' (eg: B1) ");
                        }
                        else {
                            retrieveQueryList(inputobj, userInput);
                        } }


                    //9.EXIT
                    else if (splitLine[0].equalsIgnoreCase("QUIT") || splitLine[0].equalsIgnoreCase("EXIT")) {
                            System.out.println("Goodbye!");
                        System.exit(0);
                    } else {
                        System.out.println("Invalid command ! Please use the commands provided ");
                    }
                }

            } catch (UnknownHostException e) {
                System.err.println("Don't know about host " + HOSTNAME);
                System.exit(1);
            } catch (IOException e) {
                System.err.println("Couldn't get I/O for the connection to " + HOSTNAME);
                System.exit(1);
            }
    }

    public static void retrieveListAllMethod(ObjectInputStream inputobj, String userInput) {

        ArrayList<Booking> bookings = new ArrayList<Booking>();

        try {
            Object object = inputobj.readObject(); //retrieve response and insert into object
            bookings = (ArrayList<Booking>) object;

            if (bookings.size() == 0 || bookings == null) {
                System.out.println("No result found");
            } else {
                for (Booking i : bookings) {
                    i.printBooking();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void retrieveAddMethod(ObjectInputStream inputobj, String userInput) {

        String status;

        try {
            status = (String) inputobj.readObject();

            if (status.equalsIgnoreCase("success")){
                System.out.println("Data added successfully");

            }else{
                System.out.println("Error dublicate entry");
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void retrieveUpdateMethod(ObjectInputStream inputobj, String userInput){

        String status;

        try {
            status = (String) inputobj.readObject();

            if (status.equalsIgnoreCase("success")){
                System.out.println("Data Updated successfully");

            }else{
                System.out.println("Error while Updating data, Try again please");
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void retrieveQueryList(ObjectInputStream inputobj, String userInput) {
        ArrayList<Booking> bookings = new ArrayList<Booking>();

        try {

            Object obj = inputobj.readObject();
            bookings = (ArrayList<Booking>) obj;

            if (bookings.size() == 0 || bookings == null) {
                System.out.println("No result found");
            } else if (!userInput.contains("DELETE")) {

                for (Booking i : bookings) {
                    i.printBooking();
                }
            } else {
                System.out.println("Successfully deleted: ");
                bookings.get(0).printBooking();
            }

        }catch (ClassNotFoundException e) {
            System.err.println("The title list has not come from the server");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("IO Exception: ");
            e.printStackTrace();
        }
    }

    public static void retrieveAvailableMethod(ObjectInputStream inputobj, String userInput ) {

        ArrayList<TeachingRooms> teachings = new ArrayList<TeachingRooms>();
        try {
            Object obj = inputobj.readObject();
            teachings = (ArrayList<TeachingRooms>) obj;

            if (teachings.size() == 0 || teachings == null) {
                System.out.println("No result found");
            } else  {
                for (TeachingRooms i : teachings) {
                    i.printTeachings();
                }
            }

        }catch (ClassNotFoundException e) {
            System.err.println("The title list has not come from the server");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("IO Exception: ");
            e.printStackTrace();
        }


    }



}
