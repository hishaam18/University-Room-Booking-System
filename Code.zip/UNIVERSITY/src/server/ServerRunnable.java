package server;

import common.*;
import common.Booking;
import java.net.Socket;
import java.io.*;
import java.util.*;

public class ServerRunnable implements Runnable {

    private Socket socket;

    public ServerRunnable(Socket sk) {
        socket = sk;
    }

    public void run() {

        try (   OutputStream outs = socket.getOutputStream();
                InputStream ins = socket.getInputStream();
                ObjectOutputStream writeClient=new ObjectOutputStream(outs);
                ObjectInputStream readClient=new ObjectInputStream(ins) ) {

            while (true) {

                //reading userinput sent by client
                String inputLine= (String) readClient.readObject();
                Query method = new Query();
                String[] splitLine = Split.splitLine(inputLine);


                // 1. LIST ALL bookings case
                if (splitLine[0].equalsIgnoreCase("LISTALL")) {

                    //calling listAll method from Query which returns populated arraylist booking
                    ArrayList<Booking> booking = method.listAll();
                    writeClient.reset();
                    writeClient.flush();

                    //sending booking arraylist to client
                    writeClient.writeObject(booking);
                }

                // 2. ADD a new Booking case
                else if (splitLine[0].equalsIgnoreCase("ADD") || splitLine[0].equalsIgnoreCase("add")) {

                    boolean respnse=Query.addBooking(splitLine);

                    if(respnse){  writeClient.writeObject("success"); }
                    else{
                        writeClient.writeObject("fail");
                    }
                    writeClient.flush();
                }

                // 3. List bookings for a specific LECTURER/ROOM/DATE and DELETE
                else if (splitLine[0].equalsIgnoreCase("LISTLECTURER") ||
                        splitLine[0].equalsIgnoreCase("LISTROOMNUMBER") ||
                        splitLine[0].equalsIgnoreCase("LISTDATE") ||
                        splitLine[0].equalsIgnoreCase("DELETE")) {

                    Query splitQuery = new Query();
                    ArrayList<Booking> bookings = splitQuery.queryListing(splitLine);

                    try {
                        writeClient.reset();
                        writeClient.flush();
                        writeClient.writeObject(bookings);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                //4.LIST AVAILABLE ROOM
                else if  (splitLine[0].equalsIgnoreCase("LISTAVAILABLE") || splitLine[0].equalsIgnoreCase("listavailable")) {

                    Query splitAvailableQuery = new Query();
                    ArrayList<TeachingRooms> teachings = splitAvailableQuery.listAvailable(splitLine);

                    try {
                        writeClient.reset();
                        writeClient.flush();
                        writeClient.writeObject(teachings);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }

                //5. Update booking for a specific bookingId
                else if(splitLine[0].equalsIgnoreCase("UPDATE") || splitLine[0].equalsIgnoreCase("update")) {

                    boolean response=Query.updateBooking(splitLine);

                    if(response){ writeClient.writeObject("success"); }
                    writeClient.flush();
                }
            }

        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen on port");
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    } //end run

}
