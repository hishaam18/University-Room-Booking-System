package server;

import java.sql.*;
import java.util.ArrayList;

import common.*;

public class Query {

    private static Connection DBconnect = DatabaseConnection.getConnection();

    public ArrayList<Booking> listAll() {
        ArrayList<Booking> bookings = new ArrayList<Booking>();

        try {
            Statement statement = DBconnect.createStatement();
            String query = "SELECT * FROM Booking";
            ResultSet rs = statement.executeQuery(query);

            //populating arraylist bookings
            while (rs.next()) {
                bookings.add(new Booking(rs.getString("bookingId"), rs.getString("lecturerId"), rs.getString("roomNumber"),
                        rs.getString("date"), rs.getString("time"), rs.getString("duration"),
                        rs.getString("reason"), rs.getString("noAttendees")));
            }
        } catch (SQLException ex) {
            System.out.println("Error" + ex.getMessage());
        }
        return bookings;
    }

    public static boolean addBooking(String [] addData) {

    boolean dataadded=false;
     String bookingId = addData[1];
        String lecturerId = addData[2] ;
        String roomNumber = addData[3];
        String date= addData[4];
        String time= addData[5];
        String duration= addData[6];
        String reason= addData[7];
        String noAttendees= addData[8];

        String Addquery = " INSERT INTO Booking(bookingId,lecturerId,roomNumber,date,time,duration,reason,noAttendees) VALUES(?, ?, ?, ?, ?, ?,?,?)";

        try {
            PreparedStatement preparedStatement = DBconnect.prepareStatement(Addquery);

            preparedStatement.setString(1, bookingId);
            preparedStatement.setString(2, lecturerId);
            preparedStatement.setString(3, roomNumber);
            preparedStatement.setString(4, date);
            preparedStatement.setString(5, time);
            preparedStatement.setString(6, duration);
            preparedStatement.setString(7, reason);
            preparedStatement.setString(8, noAttendees);

            preparedStatement.executeUpdate();
            System.out.print("Booking Successfully added");
            dataadded = true;


        } catch (SQLException e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                // Duplicate entry
            } else {
                // Other SQL Exception
            }
        }finally {
            return dataadded;
        }
      //  return dataadded;
    }

    public static boolean updateBooking (String[] updateData) {

        boolean dataupdated=false;

        String bookingId = updateData[1];
        String lecturerId = updateData[2] ;
        String roomNumber = updateData[3];
        String date= updateData[4];
        String time= updateData[5];
        String duration= updateData[6];
        String reason= updateData[7];
        String noAttendees= updateData[8];

        String Updatequery = "UPDATE Booking SET bookingId=?, lecturerId=?, roomNumber=?, date=?, time=?, duration=?, reason=?, noAttendees=? WHERE bookingId=?";

        try {
            PreparedStatement preparedStatement = DBconnect.prepareStatement(Updatequery);

            preparedStatement.setString(1, bookingId);
            preparedStatement.setString(2, lecturerId);
            preparedStatement.setString(3, roomNumber);
            preparedStatement.setString(4, date);
            preparedStatement.setString(5, time);
            preparedStatement.setString(6, duration);
            preparedStatement.setString(7, reason);
            preparedStatement.setString(8, noAttendees);
            preparedStatement.setString(9, bookingId);

            preparedStatement.executeUpdate();
            System.out.print("Booking Successfully updated");
            dataupdated=true;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return dataupdated;
    }

    public ArrayList<Booking> queryListing(String[] listData) {

        String data = listData[1];

        String checkQuery = null;

        switch (listData[0]) {
            case "LISTLECTURER":
                checkQuery = " SELECT * FROM Booking " + "WHERE lecturerId = ?";
                break;
            case "LISTROOMNUMBER":
                checkQuery = " SELECT * FROM Booking " + " WHERE roomNumber = ?";
                break;
            case "LISTDATE":
                checkQuery = " SELECT * FROM Booking " + " WHERE date = ?";
                break;
            case "DELETE":
                checkQuery = " SELECT * FROM Booking " + " WHERE bookingId = ?";
                break;
        }

        ArrayList<Booking> bookings = new ArrayList<Booking>();
        try {
            PreparedStatement preparedStatement = DBconnect.prepareStatement(checkQuery);
            preparedStatement.setString(1, data);


            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                bookings.add(new Booking(rs.getString("bookingId"), rs.getString("lecturerId"), rs.getString("roomNumber"),
                        rs.getString("date"), rs.getString("time"), rs.getString("duration"),
                        rs.getString("reason"), rs.getString("noAttendees")));
            }

        }catch (SQLException ex) {
            System.out.println("SQL error: " + ex.getMessage());
        }
        if (listData[0].equals("DELETE")) {
            deleteMethod(bookings, listData[1]);
        }

        return bookings;
    }

    public ArrayList<TeachingRooms> listAvailable( String[] listData) {

        ArrayList<TeachingRooms> teachings = new ArrayList<TeachingRooms>();

        String date= listData[1];
        String maximumCapacity= listData[2];
        String type= listData[3];

        String listAvailableQuery = "select * from TeachingRooms " + "where roomNumber NOT IN (select roomNumber from Booking where date=?) and maximumCapacity>=? and type=?";

        try {
            PreparedStatement preparedStatement = DBconnect.prepareStatement(listAvailableQuery);

            preparedStatement.setString(1, date);
            preparedStatement.setString(2, maximumCapacity);
            preparedStatement.setString(3, type);

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {

                teachings.add(new TeachingRooms(rs.getString("maximumCapacity"), rs.getString("type"), rs.getString("roomNumber")));
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return teachings;
    }

    public static void deleteMethod(ArrayList<Booking> bookings, String delete) {
        String query = "DELETE FROM Booking WHERE bookingId = ? ";
        if (bookings.size() != 0) {
            try {
                PreparedStatement preparedStatement = DBconnect.prepareStatement(query);
                preparedStatement.setString(1, delete);

                preparedStatement.executeUpdate();

            } catch (SQLException ex) {
                System.out.println("SQL error: " + ex.getMessage());
            }
        }

    }

}



