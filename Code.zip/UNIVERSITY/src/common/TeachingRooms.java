package common;

import java.io.Serializable;

public class TeachingRooms implements Serializable {

    private String maximumCapacity;
    private  String type;
    private String roomNumber;

    public TeachingRooms ( String mc, String tp, String rn) {
        this.maximumCapacity = mc;
        this.type = tp;
        this.roomNumber = rn;
    }

    public TeachingRooms (){}

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMaximumCapacity() {
        return maximumCapacity;
    }

    public void setMaximumCapacity(String maximumCapacity) {
        this.maximumCapacity = maximumCapacity;
    }

    public void printTeachings() {
        System.out.println(getMaximumCapacity() + '\t' + getType() + '\t' + getRoomNumber());
    }


}
