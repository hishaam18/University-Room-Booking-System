package common;

public class Split {
    public static String[] splitLine(String str) {
    String split[] = str.split(" ");
    return split;
}


}
