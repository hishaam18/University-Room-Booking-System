package common;

import java.io.Serializable;

public class Booking implements Serializable  {

    private String bookingId;
    private String lecturerId;
    private String roomNumber;
    private String date;
    private String time;
    private String duration;
    private String reason;
    private String noAttendees;

    public Booking (String bid, String lid, String rn, String d, String t, String dur, String rea, String na) {
        this.bookingId = bid;
        this.lecturerId = lid;
        this.roomNumber = rn;
        this.date = d;
        this.time = t;
        this.duration = dur;
        this.reason = rea;
        this.noAttendees = na;

    }

    public Booking (){}

    public String getNoAttendees() { return noAttendees; }

    public void setNoAttendees(String noAttendees) { this.noAttendees = noAttendees; }

    public String getReason() { return reason; }

    public void setReason(String reason) { this.reason = reason; }

    public String getDuration() { return duration; }

    public void setDuration(String duration) { this.duration = duration; }

    public String getTime() { return time; }

    public void setTime(String time) { this.time = time; }

    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public String getRoomNumber() { return roomNumber; }

    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }

    public String getLecturerId() { return lecturerId; }

    public void setLecturerId(String lecturerId) { this.lecturerId = lecturerId; }

    public String getBookingId() { return bookingId; }

    public void setBookingId(String bookingId) { this.bookingId = bookingId; }

    public void printBooking() {
        System.out.println(getBookingId() + '\t' + getLecturerId() + '\t' + getRoomNumber() + '\t' + getDate() + '\t'
                + getTime() + '\t' + getDuration() + '\t' + getReason() + '\t' + getNoAttendees());
    }

}
